//
//  HappinessViewController.swift
//  Happiness
//
//  Created by 黄之信 on 17/1/31.
//  Copyright © 2017年 MichaelHuang. All rights reserved.
//

import UIKit

class HappinessViewController: UIViewController {

}
